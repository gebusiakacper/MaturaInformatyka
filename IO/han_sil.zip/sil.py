n = int(input())

if n in [1, 2, 4, 5, 7, 10, 13]: # od 15 do 10^9
    print("NIE")
else:
    print("TAK")